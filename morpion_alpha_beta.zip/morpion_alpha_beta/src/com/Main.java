package com;
import com.Jeu;
public class Main {

	public static void main(String[] args) {
		Plateau plateau = new Plateau();
		Jeu.run(plateau);
	}

}
